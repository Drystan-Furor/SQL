<?php
// quick random phone number generator voor fictieve INSERT INTO,  RUN SCRIPT voor 1 telefoonnummer
$telefoonnummer = rand(10000000, 99999999);
echo $telefoonnummer;

